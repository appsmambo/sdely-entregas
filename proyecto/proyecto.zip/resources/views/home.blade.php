@extends('layouts.app')
@section('content')
<h2>
    Últimas órdenes
</h2>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col"># Orden</th>
                        <th scope="col">Cliente</th>
                        <th scope="col">Fecha entrega</th>
                        <th scope="col">Voucher</th>
                        <th scope="col">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                @forelse ($ordenes as $orden)
                    <tr>
                        <td>{{ $orden->id }}</td>
                        <td>{{ $orden->cliente }}</td>
                        <td>{{ $orden->entrega }}</td>
                        <td>{{ isset($orden->voucher) ? $orden->voucher : 'No' }}</td>
                        <td>
                            <a href="{{ url('/ver-orden/'. $orden->id) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ url('/cancelar-orden/'. $orden->id) }}" class="btn btn-success btn-sm">Cancelar</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5">No se encontraron registros.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
