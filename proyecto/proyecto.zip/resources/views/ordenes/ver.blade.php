@extends('layouts.app')
@section('content')
<h2>
	Orden de entrega Nro: {{ $orden->id }}
</h2>
<div class="card">
	<div class="card-body">
		<form method="post" action="#">
			<h3>Datos del cliente</h3>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Nombre</label>
						<input readonly class="form-control" value="{{ $cliente->nombres . ' ' . $cliente->apellidos }}">
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label>Documento</label>
						<input readonly class="form-control" value="{{ strtoupper($cliente->tipo_documento) . ' - ' . $cliente->documento }}">
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Correo</label>
						<input readonly class="form-control" value="{{ $cliente->correo }}">
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label>Teléfono</label>
						<input readonly class="form-control" value="{{ $cliente->telefono }}">
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Tipo de pago</label>
						<input readonly class="form-control" value="{{ $tipoPago }}">
					</div>
				</div>
				<div class="col-sm">
					<div class="row">
						<div class="col">
							<div class="form-group">
								<label>Fecha de entrega:</label>
								<input readonly class="form-control" value="{{ date('d/m/Y', strtotime($orden->fecha_hora_entrega)) }}">
							</div>
						</div>
						<div class="col">
							<div class="form-group">
								<label>Hora de entrega:</label>
								<input readonly class="form-control" value="{{ date('h:i A', strtotime($orden->fecha_hora_entrega)) }}">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm text-right mt-4">
					<a href="{{ url('home') }}" class="btn btn-secondary">Regresar</a>
					<a href="#" class="btn btn-success">Cancelar la orden</a>
				</div>
			</div>
			<hr>
			<h3>Lugar de entrega</h3>
			<div class="form-group">
				<label>Dirección:</label>
				<input readonly class="form-control" value="{{ $cliente->direccion }}">
			</div>
			<div class="form-group">
				<label>Distrito</label>
				<input readonly class="form-control" value="{{ $ubigeo->departamento . ' - ' . $ubigeo->provincia . ' - ' . $ubigeo->distrito }}">
			</div>
			<div class="form-group">
				<label>Referencia:</label>
				<input readonly class="form-control" value="{{ $cliente->referencia }}">
			</div>
			<div class="row">
				<div class="col-sm text-right mt-4">
					<a href="{{ url('home') }}" class="btn btn-secondary">Regresar</a>
					<a href="#" class="btn btn-success">Cancelar la orden</a>
				</div>
			</div>
			<hr>
			<h3>Lista de productos</h3>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
						<tr>
							<th scope="col">SKU</th>
							<th scope="col">Color</th>
							<th scope="col">Talla</th>
							<th scope="col">Cantidad</th>
						</tr>
					</thead>
					<tbody>
					@forelse ($ordenDetalle as $orden)
						<tr>
							<td>{{ $orden->sku }}</td>
							<td>{{ $orden->color }}</td>
							<td>{{ $orden->talla }}</td>
							<td>{{ $orden->cantidad }}</td>
						</tr>
					@empty
						<tr><td colspan="4">No se encontraron registros para esta orden.</td></tr>
					@endforelse
					</tbody>
				</table>
			</div>
			<p class="text-right">
				<a href="{{ url('home') }}" class="btn btn-secondary">Regresar</a>
				<a href="#" class="btn btn-success">Cancelar la orden</a>
			</p>
		</form>
	</div>
</div>
@endsection
@section('scripts')
@endsection