<?php

Route::get('/', function () {
    if (Auth::check()) {
        return redirect('home');
    } else {
        return redirect('login');
    }
});

Route::get('logout', 'HomeController@logout');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/ordenes', 'OrdenController@getOrdenes')->name('ordenes');
Route::get('/genera-orden', 'OrdenController@getGeneraOrden')->name('genera-orden');
Route::post('/genera-orden', 'OrdenController@postGeneraOrden');
Route::get('/ver-orden/{id}', 'OrdenController@getVerOrden')->name('ver-orden');

Route::post('/grabar-cliente', 'ClienteController@postGrabarCliente');


