<?php $__env->startSection('content'); ?>
<h2>
    Últimas órdenes
</h2>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col"># Orden</th>
                        <th scope="col">Cliente</th>
                        <th scope="col">Fecha entrega</th>
                        <th scope="col">Voucher</th>
                        <th scope="col">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($orden->id); ?></td>
                        <td><?php echo e($orden->cliente); ?></td>
                        <td><?php echo e($orden->entrega); ?></td>
                        <td><?php echo e(isset($orden->voucher) ? $orden->voucher : 'No'); ?></td>
                        <td>
                            <a href="<?php echo e(url('/ver-orden/'. $orden->id)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(url('/cancelar-orden/'. $orden->id)); ?>" class="btn btn-success btn-sm">Cancelar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5">No se encontraron registros.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>