<?php $__env->startSection('content'); ?>
<h2>
	Ver orden de entrega
</h2>
<div class="card">
	<div class="card-body">
		<form method="post" action="#">
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label for="cliente">Cliente</label>
						<input type="text" class="form-control" id="cliente" name="cliente" value="<?php echo e($cliente); ?>">
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label for="tipo_pago">Tipo de pago</label>
						<select class="form-control" name="tipo_pago" id="tipo_pago">
							<option value=""><?php echo e($tipoPago); ?></option>
						</select>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col-sm">
					<div class="row">
						<div class="col">
							<div class="form-group">
								<label for="fecha">Fecha de entrega:</label>
								<input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo e($orden->fecha_hora_entrega); ?>">
							</div>
						</div>
						<div class="col">
							<div class="form-group">
								<label for="hora">Hora de entrega:</label>
								<input type="time" class="form-control" id="hora" name="hora" value="<?php echo e($orden->fecha_hora_entrega); ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm text-right mt-4">
					<a href="<?php echo e(url('home')); ?>" class="btn btn-secondary">Regresar</a>
				</div>
			</div>
			<hr>
			<h3>Ingresar productos</h3>
			<div class="form-row">
				<div class="col">
					<div id="colSku" class="form-group">
						<label>SKU</label>
						<input type="text" name="sku[]" class="form-control">
					</div>
				</div>
				<div class="col">
					<div id="colColor" class="form-group">
						<label>Color</label>
						<input type="text" name="color[]" class="form-control">
					</div>
				</div>
				<div class="col">
					<div id="colTalla" class="form-group">
						<label>Talla</label>
						<input type="text" name="talla[]" class="form-control">
					</div>
				</div>
				<div id="colCantidad" class="col">
					<label>Cantidad</label>
					<div class="input-group">
						<input type="number" name="cantidad[]" class="form-control">
						<div class="input-group-append">
							<button id="agregarFila" class="btn btn-secondary btn-sm" type="button"><i class="fas fa-plus-square"></i></button>
						</div>
					</div>
				</div>
			</div>
			<p class="text-right">
				<a href="<?php echo e(url('home')); ?>" class="btn btn-secondary">Cancelar</a>
				<button type="submit" class="btn btn-primary">Grabar</button>
			</p>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>