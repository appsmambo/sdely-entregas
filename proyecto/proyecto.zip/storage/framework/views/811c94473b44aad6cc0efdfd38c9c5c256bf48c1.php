<?php $__env->startSection('content'); ?>
<h2>
	Orden de entrega Nro: <?php echo e($orden->id); ?>

</h2>
<div class="card">
	<div class="card-body">
		<form method="post" action="#">
			<h3>Datos del cliente</h3>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Nombre</label>
						<input readonly class="form-control" value="<?php echo e($cliente->nombres . ' ' . $cliente->apellidos); ?>">
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label>Documento</label>
						<input readonly class="form-control" value="<?php echo e(strtoupper($cliente->tipo_documento) . ' - ' . $cliente->documento); ?>">
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Correo</label>
						<input readonly class="form-control" value="<?php echo e($cliente->correo); ?>">
					</div>
				</div>
				<div class="col-sm">
					<div class="form-group">
						<label>Teléfono</label>
						<input readonly class="form-control" value="<?php echo e($cliente->telefono); ?>">
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col-sm">
					<div class="form-group">
						<label>Tipo de pago</label>
						<input readonly class="form-control" value="<?php echo e($tipoPago); ?>">
					</div>
				</div>
				<div class="col-sm">
					<div class="row">
						<div class="col">
							<div class="form-group">
								<label>Fecha de entrega:</label>
								<input readonly class="form-control" value="<?php echo e(date('d/m/Y', strtotime($orden->fecha_hora_entrega))); ?>">
							</div>
						</div>
						<div class="col">
							<div class="form-group">
								<label>Hora de entrega:</label>
								<input readonly class="form-control" value="<?php echo e(date('h:i A', strtotime($orden->fecha_hora_entrega))); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm text-right mt-4">
					<a href="<?php echo e(url('home')); ?>" class="btn btn-secondary">Regresar</a>
					<a href="#" class="btn btn-success">Cancelar la orden</a>
				</div>
			</div>
			<hr>
			<h3>Lugar de entrega</h3>
			<div class="form-group">
				<label>Dirección:</label>
				<input readonly class="form-control" value="<?php echo e($cliente->direccion); ?>">
			</div>
			<div class="form-group">
				<label>Distrito</label>
				<input readonly class="form-control" value="<?php echo e($ubigeo->departamento . ' - ' . $ubigeo->provincia . ' - ' . $ubigeo->distrito); ?>">
			</div>
			<div class="form-group">
				<label>Referencia:</label>
				<input readonly class="form-control" value="<?php echo e($cliente->referencia); ?>">
			</div>
			<div class="row">
				<div class="col-sm text-right mt-4">
					<a href="<?php echo e(url('home')); ?>" class="btn btn-secondary">Regresar</a>
					<a href="#" class="btn btn-success">Cancelar la orden</a>
				</div>
			</div>
			<hr>
			<h3>Lista de productos</h3>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
						<tr>
							<th scope="col">SKU</th>
							<th scope="col">Color</th>
							<th scope="col">Talla</th>
							<th scope="col">Cantidad</th>
						</tr>
					</thead>
					<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $ordenDetalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($orden->sku); ?></td>
							<td><?php echo e($orden->color); ?></td>
							<td><?php echo e($orden->talla); ?></td>
							<td><?php echo e($orden->cantidad); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr><td colspan="4">No se encontraron registros para esta orden.</td></tr>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
			<p class="text-right">
				<a href="<?php echo e(url('home')); ?>" class="btn btn-secondary">Regresar</a>
				<a href="#" class="btn btn-success">Cancelar la orden</a>
			</p>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>